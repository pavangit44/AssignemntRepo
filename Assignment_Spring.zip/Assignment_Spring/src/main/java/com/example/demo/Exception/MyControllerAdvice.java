package com.example.demo.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.demo.Exception.EmpException;

@ControllerAdvice
public class MyControllerAdvice {

	
	
	
	
	
	
	/*
	 * @ExceptionHandler(EmpException.class) public
	 * ResponseEntity<Object>empException(EmpException excep){ return new
	 * ResponseEntity<Object>(excep.getErrorMessage(),HttpStatus.BAD_REQUEST); }
	 */
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object>handleException(Exception exception){
		return new ResponseEntity<Object>("Problem in processing request ",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
	
	
}
