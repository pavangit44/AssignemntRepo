package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeTaxCalService;
import com.example.demo.VO.EmployeVO;

@RestController
@RequestMapping(path="/savedata")
public class ClientController {
  
	@Autowired
	EmployeeService service;
	@Autowired
	EmployeeTaxCalService TaxService;
	
	@PostMapping(value="/empdata")
	public String saveEmployeeDetails(@RequestBody EmployeVO details) throws Exception {
		service.saveEmployeeDeatils(details);
		return "data sucefuuly inserted";
	}
	@GetMapping(value="/empdata")
	public Object retriveTaxDetails(@RequestBody EmployeVO details)throws Exception{
		
		TaxService.calculateTax(details.getId());
		
		return"data obtained";
	}
}
