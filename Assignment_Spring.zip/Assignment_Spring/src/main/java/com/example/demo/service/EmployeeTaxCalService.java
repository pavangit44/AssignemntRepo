package com.example.demo.service;

import com.example.demo.VO.EmployeVO;

public interface EmployeeTaxCalService{

	public EmployeVO calculateTax(long employeeid);
}
