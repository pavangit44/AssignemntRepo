package com.example.demo.serviceimpl;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.Entity.Employee;
import com.example.demo.Exception.EmployeException;
import com.example.demo.Repo.EmployeeRepository;

import com.example.demo.VO.EmployeVO;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeTaxCalService;

import com.example.demo.VO.TaxResponseVO;

public class EmployeeTaxCalServiceImpl implements EmployeeTaxCalService {
	@Autowired
	EmployeeService empDetails;

	@Override
	public EmployeVO calculateTax(long employeeid) {
		EmployeVO employee = null;
		if(!(employeeid==0)) {
			try {
				employee = empDetails.getEmployeeDetails(employeeid);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			long tax=0L;
			long cess=0L;
			if(Objects.nonNull(employee)) {
				double yearlySalary = employee.getSalary()*12;
				if(yearlySalary >= 2500000) {
					cess = (long) (0.02*yearlySalary);
				}
				if(yearlySalary > 250000) {
					yearlySalary -=250000;
				}
				
				if(yearlySalary >= 250001) {
					yearlySalary -= 250000;
					tax = tax + 12500;
					if(yearlySalary > 500000) {
						yearlySalary -= 250000;
		                 tax = (long) (0.1*yearlySalary+tax);
		                 if(yearlySalary > 1000000) {
		                	tax = (long) (0.2*yearlySalary+tax);
		                 }
					}
				}
				
				TaxResponseVO response = new TaxResponseVO();
				response.setEmployeecode(employee.getEmployeeId());
				response.setFirstname(employee.getFirstName());
				response.setLastname(employee.getLastName());
				response.setTaxamount(tax);
				response.setYearlysalary((long) (employee.getSalary()*12));
				response.setCessamount(cess);
			}
		}
		return null;
	}
	
}
