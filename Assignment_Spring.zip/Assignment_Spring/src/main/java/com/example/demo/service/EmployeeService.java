package com.example.demo.service;



import com.example.demo.VO.EmployeVO;

public interface EmployeeService{

	boolean saveEmployeeDeatils(EmployeVO details) throws Exception;
	EmployeVO getEmployeeDetails(long employeeid) throws Exception;
}
